#Tue Mar 31 15:47:59 EDT 2020
lib/features/com.ibm.websphere.appserver.cdi2.0-jndi1.0.mf=10bf90fda2bdb511898e1c33a9a53d73
lib/com.ibm.ws.cdi.jndi_1.0.38.jar=6d34970c826086036c39a5f7da8dd3ba
