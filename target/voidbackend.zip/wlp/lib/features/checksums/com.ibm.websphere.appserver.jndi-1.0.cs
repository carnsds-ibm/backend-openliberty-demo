#Tue Mar 31 15:47:59 EDT 2020
lib/com.ibm.ws.org.apache.aries.jndi.api_1.1.38.jar=f5eda6f67cc897ae90f04e64e966eced
lib/com.ibm.ws.jndi_1.0.38.jar=b843c40f9ff095afedb74e9fef48c757
lib/com.ibm.ws.org.apache.aries.jndi.core_1.1.38.jar=57c53de9debc8a33ead05b2c15bf262a
lib/features/com.ibm.websphere.appserver.jndi-1.0.mf=d9ba7d4d3737b07edccf36fbdceecfe5
lib/com.ibm.ws.jndi.url.contexts_1.0.38.jar=27851e0bb4617cee6c142902959c62f4
