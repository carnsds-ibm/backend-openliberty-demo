#Tue Mar 31 15:47:56 EDT 2020
lib/com.ibm.ws.javaee.persistence.api.2.2_1.0.38.jar=8a432130f35c048c956270603eeeed7a
lib/features/com.ibm.websphere.appserver.javax.persistence-2.2.mf=94e8a241462e4d970f58fb35df160930
dev/api/spec/com.ibm.websphere.javaee.persistence.2.2_1.0.38.jar=6a1f97270cb8e91d99cbfb4299ae9978
