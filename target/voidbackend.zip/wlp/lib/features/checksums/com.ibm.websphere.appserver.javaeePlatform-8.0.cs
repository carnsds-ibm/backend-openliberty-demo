#Tue Mar 31 15:47:57 EDT 2020
lib/com.ibm.ws.javaee.version_1.0.38.jar=6d391d7ccd4ac4ec085c78e68bd13ece
lib/features/com.ibm.websphere.appserver.javaeePlatform-8.0.mf=c495c66e39e3d915941eb75c258a8c78
lib/com.ibm.ws.javaee.platform.v8_1.0.38.jar=bd6b2f4d3a07d44e2c0c80176b0edb9c
