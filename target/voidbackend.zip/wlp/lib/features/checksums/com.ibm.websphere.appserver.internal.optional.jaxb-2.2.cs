#Tue Mar 31 15:47:57 EDT 2020
lib/com.ibm.ws.org.apache.geronimo.osgi.registry.1.1_1.0.38.jar=1aec60b4bfb9fd95674cee97f1809e1e
lib/features/com.ibm.websphere.appserver.internal.optional.jaxb-2.2.mf=a2c7c0cdac73d7c07f27f3e879f9d672
dev/api/spec/com.ibm.websphere.javaee.activation.1.1_1.0.38.jar=e8ea19b733a046ddef2374345e8ae269
dev/api/spec/com.ibm.websphere.javaee.jaxb.2.2_1.0.38.jar=4c43db6567bc48c8ae2797bd21ceed13
lib/com.ibm.ws.jaxb.tools.2.2.10_1.0.38.jar=0102dc2a17d693f10143e16719fab6a5
