#Tue Mar 31 15:47:58 EDT 2020
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.rest.client.1.3_1.0.38.jar=2e5a321b860860094896f3ec30e4a206
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.rest.client-1.3.mf=ef2533b8e8cbc161033789a69c1a9dc8
