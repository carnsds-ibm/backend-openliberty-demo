#Tue Mar 31 15:47:59 EDT 2020
lib/com.ibm.ws.cdi.transaction_1.0.38.jar=c32a18818561fbf88773953591370b14
lib/features/com.ibm.websphere.appserver.cdi2.0-transaction1.2.mf=d1fb78a817285862c909202fe0a00958
