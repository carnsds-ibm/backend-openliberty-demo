#Tue Mar 31 15:47:56 EDT 2020
lib/features/com.ibm.websphere.appserver.injection-1.0.mf=f2988cf6a3731839f40be0a17af458f0
lib/com.ibm.ws.injection_1.0.38.jar=e033e6af6120a46d81fb51bd935135ec
