#Tue Mar 31 15:47:56 EDT 2020
dev/api/spec/com.ibm.websphere.javaee.connector.1.7_1.0.38.jar=ad7383c7f7acdef0ba7ed8173b54c8fb
lib/features/com.ibm.websphere.appserver.javax.connector.internal-1.7.mf=0b2968f01afc9e2b8e1ca6a5754d5883
