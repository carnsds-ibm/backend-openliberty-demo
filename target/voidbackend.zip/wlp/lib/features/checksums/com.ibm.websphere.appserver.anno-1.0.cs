#Tue Mar 31 15:47:55 EDT 2020
lib/com.ibm.ws.anno_1.1.38.jar=a806d9719319106fba1ec694c52238da
lib/features/com.ibm.websphere.appserver.anno-1.0.mf=7012b834bc74b81943abc15332b04b9d
dev/spi/ibm/com.ibm.websphere.appserver.spi.anno_1.1.38.jar=01ddf69fc07e91ad8917330dc1ecce4c
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.anno_1.1-javadoc.zip=43f36e83cf7beac1c4df7329610f9e19
