#Tue Mar 31 15:47:58 EDT 2020
lib/com.ibm.ws.require.java8_1.0.38.jar=ba78e4daaa627bd43d5fe922b9bf358c
lib/com.ibm.ws.org.apache.cxf.cxf.rt.rs.mp.client.3.3_1.0.38.jar=59b4e57eb60a60e5aae08ddd8ed7d991
lib/features/com.ibm.websphere.appserver.mpRestClient-1.3.mf=3eb6838edb9e9a69f52cf4003d561436
