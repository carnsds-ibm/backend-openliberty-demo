#Tue Mar 31 15:47:56 EDT 2020
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.transaction_1.1-javadoc.zip=5e816cec08dd1355d752d6862beb6a9f
dev/api/spec/com.ibm.websphere.javaee.transaction.1.2_1.0.38.jar=ffaae4a2c75230ce35dea0cb850181c7
dev/api/ibm/com.ibm.websphere.appserver.api.transaction_1.1.38.jar=6c8adf0540a0ae93c84f37930b79bcba
lib/features/com.ibm.websphere.appserver.jta-1.2.mf=e761a0da8b371737932474aa623740ca
