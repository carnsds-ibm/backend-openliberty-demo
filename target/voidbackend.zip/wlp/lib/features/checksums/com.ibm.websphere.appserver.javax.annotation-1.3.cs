#Tue Mar 31 15:47:55 EDT 2020
lib/features/com.ibm.websphere.appserver.javax.annotation-1.3.mf=b992a0f3c28602ad0ee52b1c44950a7a
dev/api/spec/com.ibm.websphere.javaee.annotation.1.3_1.0.38.jar=333b6f5035ef9d86a4f33ba20003057b
