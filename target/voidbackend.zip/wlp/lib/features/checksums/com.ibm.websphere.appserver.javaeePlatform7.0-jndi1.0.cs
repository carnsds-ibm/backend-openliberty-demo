#Tue Mar 31 15:47:59 EDT 2020
lib/features/com.ibm.websphere.appserver.javaeePlatform7.0-jndi1.0.mf=80d4920a496d4be01298f52cad4798f5
lib/com.ibm.ws.javaee.platform.v7.jndi_1.0.38.jar=0669aaf8b00c1a854b349db569f27cfd
