#Tue Mar 31 15:47:56 EDT 2020
dev/api/spec/com.ibm.websphere.javaee.ejb.3.2_1.0.38.jar=9096f5726e200c5cf7dd8889fa2c2b0d
lib/features/com.ibm.websphere.appserver.javax.ejb-3.2.mf=781d037d65ac6a077507ca78dd403dbe
