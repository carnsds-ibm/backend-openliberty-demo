#Tue Mar 31 15:47:59 EDT 2020
lib/com.ibm.ws.microprofile.config.1.1.cdi_1.0.38.jar=92fd3efe21860c75e47631cd8a7dd84b
lib/com.ibm.ws.microprofile.config.1.2.cdi_1.0.38.jar=d9e7a1511f5930e3aac1ee977b955b26
lib/features/com.ibm.websphere.appserver.mpConfig1.2-cdi1.2.mf=73c9f1c163e6ddae9efa5ea2ab29c366
lib/com.ibm.ws.microprofile.config.1.2.cdi.services_1.0.38.jar=4620c53f3dc17c351a63d0182f311ddd
