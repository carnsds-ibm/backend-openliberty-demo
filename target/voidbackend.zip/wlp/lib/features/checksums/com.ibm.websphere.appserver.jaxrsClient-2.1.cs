#Tue Mar 31 15:47:58 EDT 2020
lib/com.ibm.ws.cxf.client_1.0.38.jar=1300cb01841655da1efc4cb0bdf9c45f
lib/com.ibm.ws.jaxrs.2.0.client_1.0.38.jar=7c33a8c6d8b8dbe9c4921a3d0a9aae59
lib/features/com.ibm.websphere.appserver.jaxrsClient-2.1.mf=62a10847386aaaa6db5ba4e15a201405
