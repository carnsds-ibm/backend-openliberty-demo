#Tue Mar 31 15:47:58 EDT 2020
lib/features/com.ibm.websphere.appserver.mpRestClient1.0-cdi1.2.mf=2952dd25e5c53a18d16faf6eddb35f25
lib/com.ibm.ws.microprofile.rest.client.cdi_1.0.38.jar=5c38a0a93c858af2841f20cfbd2b1f13
