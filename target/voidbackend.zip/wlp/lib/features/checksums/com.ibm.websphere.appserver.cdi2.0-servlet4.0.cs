#Tue Mar 31 15:47:59 EDT 2020
lib/features/com.ibm.websphere.appserver.cdi2.0-servlet4.0.mf=1fd431e525be71ca600012229ef78d0b
dev/api/spec/com.ibm.websphere.javaee.jsp.2.3_1.0.38.jar=740da80fb0f5bd3110ccffde612392f3
lib/com.ibm.ws.cdi.2.0.web_1.0.38.jar=36f50921a25b22176c5679309efece44
lib/com.ibm.ws.cdi.web_1.0.38.jar=bff856fcece237761e87bea2f54299ae
