#Tue Mar 31 15:47:57 EDT 2020
dev/api/spec/com.ibm.websphere.javaee.jsonb.1.0_1.0.38.jar=50eac205fe1bd0fc078ce22f6da64992
lib/features/com.ibm.websphere.appserver.jsonbImpl-1.0.1.mf=94beacb552067ac7f2d1a44d30ff9ffb
lib/com.ibm.ws.org.eclipse.yasson.1.0_1.0.38.jar=af093257f4cb029eaf4fdda01453cf17
