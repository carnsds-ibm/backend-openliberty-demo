#Tue Mar 31 15:47:56 EDT 2020
lib/features/com.ibm.websphere.appserver.internal.slf4j-1.7.7.mf=0f0d052bb87c8068bfacb2a2aa3d62fa
lib/com.ibm.ws.org.slf4j.api.1.7.7_1.0.38.jar=fd2ec6e381ade3f51cb7527d8d1aefbc
lib/com.ibm.ws.org.slf4j.jdk14.1.7.7_1.0.38.jar=a2003b0c9ddf7ef3c8ab222bff21525e
