#Tue Mar 31 15:47:56 EDT 2020
dev/api/spec/com.ibm.websphere.javaee.jsp.2.3_1.0.38.jar=740da80fb0f5bd3110ccffde612392f3
lib/features/com.ibm.websphere.appserver.javax.jsp-2.3.mf=904d954f7ef086b758742fab1db0b0ee
