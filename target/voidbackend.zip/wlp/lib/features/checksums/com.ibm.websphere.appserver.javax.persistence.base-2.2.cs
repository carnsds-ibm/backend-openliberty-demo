#Tue Mar 31 15:47:56 EDT 2020
lib/com.ibm.ws.javaee.persistence.2.2_1.0.38.jar=3be2693ee597d65ab1df050518970cc7
lib/features/com.ibm.websphere.appserver.javax.persistence.base-2.2.mf=3fed818f0a416e309626e84bb3faecc5
