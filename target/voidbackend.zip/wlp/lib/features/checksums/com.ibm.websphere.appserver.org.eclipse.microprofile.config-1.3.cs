#Tue Mar 31 15:47:56 EDT 2020
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.config.1.3_1.0.38.jar=63e680a222971250bbd68cd64e27eb08
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.config-1.3.mf=a4b36ddc5f45a61599a78f4b87f60226
