#Tue Mar 31 15:47:56 EDT 2020
dev/api/spec/com.ibm.websphere.javaee.cdi.2.0_1.0.38.jar=12cb0d8c2d4f211758e7b795fe418f67
lib/features/com.ibm.websphere.appserver.javax.cdi-2.0.mf=511e3145dfb4f2c85ca7512010cc44ad
