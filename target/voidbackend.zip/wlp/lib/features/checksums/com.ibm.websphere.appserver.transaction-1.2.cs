#Tue Mar 31 15:47:56 EDT 2020
lib/features/com.ibm.websphere.appserver.transaction-1.2.mf=368c95ccb85c06a8b5a942591f708ab2
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.transaction_1.1-javadoc.zip=795ebc22563f2fb77f926e79e56f77ad
lib/com.ibm.ws.transaction_1.0.38.jar=e04395b351a8fb8ac7d60d6602704f9a
lib/com.ibm.ws.recoverylog_1.0.38.jar=317150bbb6f52eb48fe71b9eb86d6e61
lib/com.ibm.ws.tx.jta.extensions_1.0.38.jar=8a7ad648c1601fa965d3513516f9d8ab
lib/com.ibm.ws.transaction.cdi_1.0.38.jar=a0a545356562eb1ec60d1cbd0c476637
lib/com.ibm.tx.jta_1.0.38.jar=35efa40437370cb64045f62f87b7db26
lib/com.ibm.ws.tx.embeddable_1.0.38.jar=599dd2a468ea2353ad34e872fc2dc734
lib/com.ibm.tx.ltc_1.0.38.jar=38926d84bbae8f284b1f9d8fcff3a766
lib/com.ibm.rls.jdbc_1.0.38.jar=c9f262ef70f62b5803e650d60f05e2ca
lib/com.ibm.tx.util_1.0.38.jar=185d075b9e28ef3aa389a04ad5fd796c
dev/spi/ibm/com.ibm.websphere.appserver.spi.transaction_1.1.38.jar=415435bdc25688afbb379495f210e5b8
lib/com.ibm.ws.cdi.interfaces_1.0.38.jar=82c29ef2fe80e5cfa07cf64068d7f72c
