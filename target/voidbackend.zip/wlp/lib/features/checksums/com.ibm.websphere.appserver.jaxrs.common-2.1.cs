#Tue Mar 31 15:47:58 EDT 2020
lib/com.ibm.ws.jaxrs.2.1.common_1.0.38.jar=8187954f973e8ad4c108809b34e6c89f
lib/com.ibm.ws.org.apache.cxf.cxf.rt.rs.service.description.3.2_1.0.38.jar=79f4a51be550c19d82bf87ffcf8d60ec
lib/com.ibm.ws.org.apache.cxf.cxf.rt.rs.client.3.2_1.0.38.jar=e1c28fe18ebb2b7069980c123e05e607
lib/com.ibm.ws.org.apache.cxf.cxf.rt.frontend.jaxrs.3.2_1.0.38.jar=b22fc568251822ce6b273199b8a4c3a2
bin/jaxrs/wadl2java=8c1f6a7b7ae800d88c6c81abc2bfcb52
lib/com.ibm.ws.org.apache.cxf.cxf.rt.rs.sse.3.2_1.0.38.jar=03260313a0c36777a443c2c1586b9cf4
bin/jaxrs/wadl2java.bat=618f62d1ea9b747dcbe59acad580189c
dev/api/spec/com.ibm.websphere.javaee.jaxws.2.2_1.0.38.jar=318400d18ee06db70409d8e72f5f7406
lib/com.ibm.ws.org.apache.cxf.cxf.tools.wadlto.jaxrs.3.2_1.0.38.jar=b53b3112a59b18d0747d48bd4ba7a77c
dev/api/spec/com.ibm.websphere.javaee.jws.1.0_1.0.38.jar=e60d72d818e54ec80ae6f8da67747f84
bin/jaxrs/tools/wadl2java.jar=cfd1245fff283fdb1cf51ab50437e3a9
lib/com.ibm.ws.org.apache.cxf.cxf.rt.transports.http.hc.3.2_1.0.38.jar=c0b893cdfdea7def211d165a0e0ac507
dev/api/ibm/com.ibm.websphere.appserver.api.jaxrs20_1.0.38.jar=689d2288d90731720904f9f31bb70d23
lib/com.ibm.ws.jaxrs.2.x.config_1.0.38.jar=4f3338e57d22c5d366ade6fcaa5ed6f6
lib/com.ibm.ws.org.apache.cxf.cxf.tools.common.3.2_1.0.38.jar=0bf107a2ab927244df6dcf8ef8a2691e
lib/com.ibm.ws.jaxrs.2.0.tools_1.0.38.jar=03228193652c8a5da4b139d7acc39b72
lib/features/com.ibm.websphere.appserver.jaxrs.common-2.1.mf=e8bb2d20de79fcca506f58428c2d1dc5
