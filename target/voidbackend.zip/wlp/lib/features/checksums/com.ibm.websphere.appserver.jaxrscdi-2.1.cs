#Tue Mar 31 15:47:59 EDT 2020
lib/com.ibm.ws.jaxrs.2.0.cdi_1.0.38.jar=c10087ec2ca4bcb5ddb18e38fc80edcb
lib/features/com.ibm.websphere.appserver.jaxrscdi-2.1.mf=6fec4c955e0239213f7fb92c4f05f065
