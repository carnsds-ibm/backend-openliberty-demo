#Tue Mar 31 15:47:57 EDT 2020
dev/api/spec/com.ibm.websphere.javaee.jsonp.1.1_1.0.38.jar=69450a857748b0b4834e5947d2df338f
lib/com.ibm.ws.org.glassfish.json.1.1_1.0.38.jar=eb2cc5c5a4d8e613b98b338200d3d024
lib/features/com.ibm.websphere.appserver.jsonpImpl-1.1.1.mf=e58cfc6edd386dcf172265b7115dd297
