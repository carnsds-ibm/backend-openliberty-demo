#Thu Mar 05 16:19:52 GMT 2020
lib/platform/defaultLogging-1.0.mf=5dca00ad3a1c72fd06670dc28717f34f
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.logging_1.1-javadoc.zip=6735f058432bfb8247189b60bd372abd
lib/com.ibm.ws.logging.osgi_1.0.38.jar=1978bd58251d71bee4b0483759f88995
lib/com.ibm.ws.logging_1.0.38.jar=b7083812e061128a50309b291867c33b
lib/com.ibm.ws.collector.manager_1.0.38.jar=5170dc65dc307b95f87ddf0e2a3fd0c9
dev/spi/ibm/com.ibm.websphere.appserver.spi.logging_1.1.38.jar=21369493343310555decd91903deb7ec
